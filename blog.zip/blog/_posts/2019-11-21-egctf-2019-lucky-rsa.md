---
layout: post
title: EGCTF 2019 - Lucky RSA
---

We've seen this challenge during EG-CTF 2019, and while we didn't solve it during the CTF, the challenge looked interesting so I attempted it post-CTF.

## Description
> Category: Crypto, Solves: 0, Score: 400
> This RSA modulus has too much 7s, someone was very lucky!
> 
> Flag format: flag{ASCII++}
> File: RSA.txt
> 
> Hint: decimal is for noobs
> RSA.txt
>
> n = 593156795274816364401276413094088780537773147362965623
> 8687412333269919974129680051654265214941682323959748165218
> 3363496082434832838806644157006726856494536116021653621019
> 8790256466958036925625119429529844128660251852613540593431
> 6494374578006124644646729751928248997025480163169775252738
> 20743630732438503831583274043551
>
> c = 912105888664330346560991492855480919711266369162058383
> 9041317077850944111852933612745911276954831493827713569388
> 4700594990089886706426187091880962749384922319103040011364
> 9335338149454316985263066207230289174641471408885124387614
> 7696003205038619488007379077929861833241809815368501068949
> 8189302741991850669325041915770
>
> e = 31337


## Analysis
I've got to say, this is a lovely challenge. Off the bat, we're only given an RSA public key \\(n, e\\) and the ciphertext encrypted with that public key, \\(c\\). The challenge description says something about seven? It's also rather straight-forward: non-interactive, nothing really but a public key and an encrypted message.

During the CTF, I thought I'd check off a few standard things:
1. The choice of the public exponent, \\(e\\), is out of the norm, but seems large enough. Coppersmith probably won't be of immediate help to us here.
2. Is \\(n\\) a prime? Nope.
3. Are \\(n\\) and \\(e\\) co-prime? Yes.

Hm. Nothing so far, and my quick runs of tools that'd try a plethora of attacks yielded nothing. We were given a hint that decimal is for noobs, but I had already moved on since we were behind on a lot of other challenges.

**Fast forward a couple of days**
