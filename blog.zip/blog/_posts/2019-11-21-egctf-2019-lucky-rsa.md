---
layout: post
title: EGCTF 2019 - Lucky RSA
---

We've seen this challenge during EG-CTF 2019, and while we didn't solve it during the CTF, the challenge looked interesting so I attempted it post-CTF.

## Description
> Category: Crypto, Solves: 0, Score: 400
> This RSA modulus has too much 7s, someone was very lucky!
> 
> Flag format: flag{ASCII++}
> File: RSA.txt
> 
> Hint: decimal is for noobs
> RSA.txt
>
> n = 593156795274816364401276413094088780537773147362965623
> 8687412333269919974129680051654265214941682323959748165218
> 3363496082434832838806644157006726856494536116021653621019
> 8790256466958036925625119429529844128660251852613540593431
> 6494374578006124644646729751928248997025480163169775252738
> 20743630732438503831583274043551
>
> c = 912105888664330346560991492855480919711266369162058383
> 9041317077850944111852933612745911276954831493827713569388
> 4700594990089886706426187091880962749384922319103040011364
> 9335338149454316985263066207230289174641471408885124387614
> 7696003205038619488007379077929861833241809815368501068949
> 8189302741991850669325041915770
>
> e = 31337


## Analysis
{% katexmm %}
I've got to say, this is a lovely challenge. Off the bat, we're only given an RSA public key $n, e$ and the ciphertext encrypted with that public key, $c$. The challenge description says something about seven? It's also rather straight-forward: non-interactive, nothing really but a public key and an encrypted message.

During the CTF, I thought I'd check off a few standard things:
1. The choice of the public exponent, $e$, is out of the norm, but seems large enough. Coppersmith probably won't be of immediate help to us here.
2. Is $n$ a prime? Nope.
3. Are $n$ and $e$ co-prime? Yes.

Hm. Nothing so far, and my quick runs of tools that'd try a plethora of attacks yielded nothing. We were given a hint, "decimal is for noobs", but we had already moved on to catch up with other challenges.

{% endkatexmm %}

_Fast forward a couple of days_

Taking another look at the challenge, the hint indicates that we should represent the parameters in a different base, and since the challenge keeps mentioning sevens, let's try base7:
```python
In [2]: from gmpy2 import mpz                                                                        

In [3]: mpz(n).digits(7)                                                                             
Out[3]: '10160602300000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001314534626100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001310034'
```

That's a 377-digit modulus (in base 7) that is mostly just zeroes! This modulus is not sufficiently random, so we can do something about it. Let's unpack what is going on step by step.

## Solution
{% katexmm %}

For a given base $B$, an $m$-digit number $x$ and a positive integer $l$ such that $l < m$,  we can represent $x$ as:
$$\tag{1} x = x_{1} \times B^l + x_{0}$$

Assuming that $n = p \times q$ for some primes $p$ and $q$, as in the standard RSA case, we can start building a set of equations from $(1)$:
$$\tag{2} n = X \times 7^a + Y \times 7^b + Z$$
$$\tag{3} p = r_{1} \times 7^k + r_{0}$$
$$\tag{4} q = t_{1} \times 7^s + t_{0}$$

From $(2)$, $(3)$ and $(4)$ in addition to the definition of $n$, we get to the following set of equivalencies, assuming without loss of generality (WLOG) that $p > q$:
$$
\tag{5} \begin{aligned}
n & = p \times q \\
& = (r_{1} 7^k + r_{0}) \times (t_{1} 7^s + t_{0}) & \\
& = r_{1} t_{1} 7^{k+s} + (r_{1} t_{0} 7^k + r_{0} t_{1} 7^s) + r_{0} t_{0} & \\
& = r_{1} t_{1} 7^{k+s} + 7^{\min(k, s)} \times (r_{1} t_{0} 7^{k - \min(k, s)}  + r_{0} t_{1} 7^{s - \min(k, s)}) + r_{0} t_{0} & \\
& = r_{1} t_{1} 7^{k+s} + 7^{s} \times (r_{1} t_{0} 7^{k - s}  + r_{0} t_{1}) + r_{0} t_{0} & (\text{since}\ p > q) \\
& = X \times 7^a + Y \times 7^b + Z & 
\end{aligned}
$$

So we know that $X = r_{1} t_{1}$ and $Z = r_{0} t_{0}$ for some configuration of $a$, $b$, $k$ and $s$ such that $a = k + s$ and $b = \min(k, s)$. A proof of why such a configuration will always exist is left as an exercise for the reader ;)

We also know exactly what $X$, $Y$, $Z$, $a$ and $b$ in $(2)$ are:
$$n = (101606023)_7 \times 7^{368} + (13145346261)_7 \times 7^{182} + (1310034)_7$$

So we can factorize $X$ and $Z$ into $r_1$, $r_0$, $t_1$ and $t_0$ since the numbers are rather small. We'll use [Wolfram Alpha](https://www.wolframalpha.com/) for that and then we'll try all possible combinations of $t_1$ and $t_0$ to get $q = t_1 7^{182} + t_0$, from there we can get the private exponent $d$ and decrypt the message:
{% endkatexmm %}

```python
In [11]: from crypto_commons.generic import long_to_bytes                                            

In [12]: from gmpy2 import invert                                                                    

In [13]: from itertools import product                                                               

In [14]: Xfactors = [1, 191, 31337, 5985367] 
    ...: Zfactors = [1, 2, 3, 4, 6, 8, 9, 12, 16, 18, 24, 32, 36, 37, 48, 64, 72, 74, 96, 111, 128, 1
    ...: 44, 148, 192, 222, 256, 288, 296, 333, 384, 444, 512, 576, 592, 666, 768, 888, 1152, 1184, 1
    ...: 332, 1536, 1776, 2304, 2368, 2664, 3552, 4608, 4736, 5328, 7104, 9472, 10656, 14208, 18944, 
    ...: 21312, 28416, 42624, 56832, 85248, 170496] 
    ...:                                                                                             

In [15]: for t1, t0 in product(Xfactors, Zfactors): 
    ...:     q = t1 * pow(7, 182) + t0 
    ...:     if (n % q) == 0: 
    ...:         p = n // q 
    ...:         break 
    ...:                                                                                             

In [16]: p, q                                                                                        
Out[16]: 
(2946244670278159595494345449342531541795817488936539128741634781408706031401483595398900712941275209698016303082388363058074124628627547054654027776366527643151,
 201326387200155884533290673707174608584240712641121013446353306421200199973458466103816585239223493802335276727395008042353358097928876585130744538004448140401)

In [17]: d = invert(e, (p - 1) * (q - 1))                                                            

In [18]: message = pow(c, d, n)                                                                      

In [19]: print(long_to_bytes(message))                                                               
b'flag{777_RSA_777_digits}'
```

## Flag
`flag{777_RSA_777_digits}`

